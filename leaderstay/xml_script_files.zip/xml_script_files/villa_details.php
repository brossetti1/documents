<?php 
require_once("info.php");

$villaid = $_GET['villaid'];

$param = array(	'id'=>$TO_id, 'villaid' => $villaid);

$reply = $client->call('getAvailableInfo',array('parameters' => $param));
?>
<style type="text/css">
.exponent {
	position: relative;
	bottom: 0.5em;
	font-size: 0.8em;
}
</style>
<?php
if ($client->fault){
	print_r($reply);
} else {
	$err=$client->getError();
	if ($err!="")
		echo $err;
	else {
		foreach ($reply as $r ) {
			$villaname = $r['name'];
			$villatype = $r['property_type'];
			echo "<center><h1>".$villatype." ".$villaname."</h1></center>";

			//---------------------------------IMAGES---------------------------------
			$imageList = $r['imageList'];
			$images = array();
			foreach ($imageList as $am ) {
				$images[$am['priority']-1] = $am['path'];
			}
			$firstimage = $images[0];
			echo "<img src=\"" . $firstimage . "\" alt=\"\" width=\"342px\" height=\"225px\">"; //90 68
			
			//---------------------------------DESCRIPTION---------------------------------
			if( $r['description'] != NULL && $r['description'] != "" ) {
				echo "<h3 style=\"line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px\"><span>Description</span></h3>" . strip_tags($r['description'], '<p>');
			}
			
			$imagessize = count($images);
			if( $imagessize > 0 ) {
			?>
                <h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px">Click to see larger photos</h3>
			<!-- Use a preview mechanism in the following photos -->
			<?php 
			}
			
			for( $i=0; $i<$imagessize; $i++ ) {
				$image = $images[$i];
				echo "<a href=\"".$image."\" target=\"_blank\"><img src=\"".$image."\" width=\"60px\" height=\"45px\" style=\"border:none;\" /></a>";
			}

			//---------------------------------BASICS---------------------------------
			echo "<h3 style=\"line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px\"><span>Basic Characteristics</span></h3>";
			echo "<b>Location: </b>" . $r['street_address'] . ", " . $r['area'] . ", " . $r['region'] . ", " . $r['country'] . "<br />";
			if ($r['built'] != NULL && $r['built'] !== "" && $r['built'] !== "1")
				echo "<b>Built: </b>" . $r['built'] . "<br />";
			if ($r['renovated'] != NULL && $r['renovated'] !== "" && $r['renovated'] !== "1")
				echo "<b>Renovated: </b>" . $r['renovated'] . "<br />";
			if ($r['size_SQM'] != NULL && $r['size_SQM'] !== "" && $r['size_SQM'] !== "1")
				echo "<b>Size: </b>" . $r['size_SQM'] . "m<span class=\"exponent\">2</span><br />";
			if ($r['grounds_SQM'] != NULL && $r['grounds_SQM'] !== "" && $r['grounds_SQM'] !== "1")
				echo "<b>Grounds: </b>" . $r['grounds_SQM'] . "m<span class=\"exponent\">2</span><br />";
			if ($r['floors_no'] != NULL && $r['floors_no'] !== "" && $r['floors_no'] !== "1")
				echo "<b>Floors number: </b>" . $r['floors_no'] . "<br />";
			if ($r['view'] != NULL && $r['view'] !== "" && $r['view'] !== "1")
				echo "<b>View: </b>" . $r['view'] . "<br />";
			if ($r['max_persons'] != NULL && $r['max_persons'] !== "" )
				echo "<b>Max number of persons: </b>" . $r['max_persons'] . "<br />";
			if ($r['change_of_sheets'] != NULL && $r['change_of_sheets'] !== "" && $r['change_of_sheets'] !== "1" )
				echo "<b>Change of sheets: </b>" . $r['change_of_sheets'] . "<br />";
			echo "<b>Check-in / Check-out time: </b>" . $r['checkin_time'] . " / " . $r['checkout_time'] . "<br />";
			$latitude = "";
			$longitude = "";
			if( $r['googleCoordinates']['is_accurate'] == 1 ) {
				echo "<b>Coordinates: </b>(".$r['googleCoordinates']['latitude'].",".$r['googleCoordinates']['longitude'].")<br />";
			}
			
			//---------------------------------ROOM---------------------------------
			$rooms_ac = array();
			$roomsacList = $r['roomsacList'];
			if( $roomsacList != NULL && count($roomsacList) > 0 ) {
				foreach ($roomsacList as $am ) {
					$rooms_ac[$am['name']] = 1;
				}
			}

			$roomsList = $r['roomsList'];
			$i = 0;
			$listoutput = "";
			if( $roomsList != NULL && count($roomsList) > 0 ) {
				foreach ($roomsList as $am ) {
					if ($am['quantity'] > 1) {
						$roomplural = $am['name'];
						if ($am['name'] === "balcony") {
							$roomplural = "balconies";
						} elseif (preg_match("/bedrooms/i", $am['name']) == false && preg_match("/WC/i", $am['name']) == false) {
							$roomplural = $am['name'] . "s";
						}
						$listoutput .= $am['quantity'] . " " . $roomplural;
						$hasac = 0;
						for( $j=1; $j<=$am['quantity']; $j++ ) {
							if ($rooms_ac[$am['name'] . " #" . $j] == 1) {
								$hasac++;
							}
						}
						if( $hasac > 0 ) {
							if( $hasac == $am['quantity'] ) $listoutput .= " (air-conditioned)";
							else {
								$listoutput .= " (".$hasac." of them ";
								if( $hasac == 1 ) echo "is ";
								else $listoutput .= "are ";
								$listoutput .= "air-conditioned)";
							}
						}
						$listoutput .= ", ";
					} else {
						$roomsingle = $am['name'];
						$roomsingle = str_replace("bedrooms", "bedroom", $am['name']);
						$listoutput .= $roomsingle;
						if ($rooms_ac[$am['name']] == 1) {
							$listoutput .= " (air-conditioned) ";
						}
						$listoutput .= ", ";
					}
					$i++;
				}
			}
			if ($i > 0) {
				$listoutput = substr($listoutput, 0, -2);
				$listoutput .= "<br />";
			?>
				<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Rooms</span></h3>                
			<?php
				echo $listoutput;
			}
			
			//---------------------------------BATHROOM---------------------------------
			$bathroom_facilitiesList = $r['bathroom_facilitiesList'];
			$bathrooms = array();
			if( $bathroom_facilitiesList != NULL && count($bathroom_facilitiesList) > 0 ) {
				foreach ($bathroom_facilitiesList as $am ) {
					if( $bathrooms[$am['room']] == NULL ) {
						$bathrooms[$am['room']] = 1;
					}
				}
				
				foreach ($bathroom_facilitiesList as $am ) {
					if ($bathroom[$am['room']] == NULL) {
						$bathroom[$am['room']] = array();
					}
					array_push($bathroom[$am['room']], $am['name']);
				}
				
				$listoutput = "";
				$i = 0;
				foreach ($bathrooms as $bathitem=>$bathvalue) {
					$listoutput .= "<b>" . str_replace("#", "", $bathitem) . "</b>: ";
					$j = 0;
					foreach ($bathroom[$bathitem] as $item) {
						$listoutput .= $item . ", ";
						$j++;
					}
					if ($j > 0) {
						$listoutput = substr($listoutput, 0, -2);
					}
					$listoutput .= "<br />";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Bathroom Facilities</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------BED---------------------------------
			$bedList = $r['bedList'];
			if( $bedList != NULL && count($bedList) > 0 ) {
				$bedrooms = array();
				foreach ($bedList as $am ) {
					if( $bedrooms[$am['room']] == NULL ) {
						$bedrooms[$am['room']] = 1;
					}
				}
				
				$bedroom = array();
				foreach ($bedList as $am ) {
					if ($bedroom[$am['room']] == NULL) {
						$bedroom[$am['room']] = array();
					}
					array_push($bedroom[$am['room']], $am['name'] . "|" . $am['quantity']);
				}
				
				$listoutput = "";
				$i = 0;
				foreach ($bedrooms as $beditem=>$bedvalue) {
					$beditemoutput = str_replace("bedrooms", "bedroom", $beditem);
				
					$listoutput .= "<b>" . str_replace("#", "", $beditemoutput) . "</b>: ";
					$j = 0;
					foreach ($bedroom[$beditem] as $item) {
						$items = explode('|', $item);
						$listoutput .= $items[1] . " " . $items[0] . ", ";
						$j++;
					}
					if ($j > 0) {
						$listoutput = substr($listoutput, 0, -2);
					}
					$listoutput .= "<br />";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Beds</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------INTERNET---------------------------------
			$internetoutput = "";
			$internetList = $r['internetList'];
			if( $internetList != NULL && count($internetList) > 0 ) {
				$i = 0;
				foreach ($internetList as $am ) {
					$internetoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$internetoutput = substr($internetoutput, 0, -2);
					$internetoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Internet</span></h3>                
				<?php
					echo $internetoutput;
				}
			}
			
			//---------------------------------POOL---------------------------------
			$poolList = $r['poolList'];
			if( $poolList != NULL && count($poolList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($poolList as $am ) {
					$listoutput .= $am['quantity'] . " " . $am['name'];
					if ($am['heated'] == 1)
						$listoutput .= " (heated)";
					$listoutput .= ", size = " . $am['size'] . "m<span class=\"exponent\">2</span>, ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Pool</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------STAFF---------------------------------
			$staffList = $r['stuffList'];
			if( $staffList != NULL && count($staffList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($staffList as $am ) {
					$listoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Staff</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------AMENITIES---------------------------------
			$amenitiesList = $r['amenitiesList'];
			if( $amenitiesList != NULL && count($amenitiesList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($amenitiesList as $am ) {
					$listoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Amenities</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------KITCHEN AMENITIES---------------------------------
			$kitchen_amenitiesList = $r['kitchen_amenitiesList'];
			if( $kitchen_amenitiesList != NULL && count($kitchen_amenitiesList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($kitchen_amenitiesList as $am ) {
					$listoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Kitchen Amenities</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------OUTSIDE AMENITIES---------------------------------
			$outside_amenitiesList = $r['outside_amenitiesList'];
			if( $outside_amenitiesList != NULL && count($outside_amenitiesList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($outside_amenitiesList as $am ) {
					$listoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Outside Amenities</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------SUITABILITY---------------------------------
			$suitabilityList = $r['suitabilityList'];
			if( $suitabilityList != NULL && count($suitabilityList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($suitabilityList as $am ) {
					$listoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Suitability</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------LOCATION TYPE---------------------------------
			$location_typeList = $r['location_typeList'];
			if( $location_typeList != NULL && count($location_typeList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($location_typeList as $am ) {
					$listoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Location Type</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------LOCAL AREA ACTIVITIES---------------------------------
			$local_area_activitiesList = $r['local_area_activitiesList'];
			if( $local_area_activitiesList != NULL && count($local_area_activitiesList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($local_area_activitiesList as $am ) {
					$listoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Local Area Activities</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			//---------------------------------ATTRACTIONS---------------------------------
			$attractionsList = $r['attractionsList'];
			if( $attractionsList != NULL && count($attractionsList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($attractionsList as $am ) {
					$listoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Attractions</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------LEISURE ACTIVITIES---------------------------------
			$leisure_activitiesList = $r['leisure_activitiesList'];
			if( $leisure_activitiesList != NULL && count($leisure_activitiesList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($leisure_activitiesList as $am ) {
					$listoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Leisure Activities</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------NEARBY ATTRACTION ACTIVITIES---------------------------------
			$nearby_attraction_facilitiesList = $r['nearby_attraction_facilitiesList'];
			if( $nearby_attraction_facilitiesList != NULL && count($nearby_attraction_facilitiesList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($nearby_attraction_facilitiesList as $am ) {
					$listoutput .= $am['name'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Nearby Attraction Facilities</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------DISTANCES---------------------------------
			$distancesList = $r['distancesList'];
			if( $distancesList != NULL && count($distancesList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($distancesList as $am ) {
					$listoutput .= "<b>" . $am['kind'] . "</b> (" . $am['name'] . "): " . $am['km'] . "km<br />";
					$i++;
				}
				if ($i > 0) {
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Distances</span></h3>                
				<?php
					echo $listoutput;
				}
			}

			
			//---------------------------------EXTRAS---------------------------------
			$extraList = $r['extraList'];
			if( $extraList != NULL && count($extraList) > 0 ) {
				$i = 0;
				$listoutput = "";
				foreach ($extraList as $am ) {
					$listoutput .= $am['name'] . ": " . $am['price'] . " " . $am['currency'] . ", ";
					$i++;
				}
				if ($i > 0) {
					$listoutput = substr($listoutput, 0, -2);
					$listoutput .= "<br />";
				?>
					<h3 style="line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px"><span>Extras</span></h3>                
				<?php
					echo $listoutput;
				}
			}
			
			//---------------------------------TERMS---------------------------------
			if( $r['terms'] != NULL && $r['terms'] != "" ) {
				echo "<h3 style=\"line-height:0.7em; color:#000; padding:37px 0 0 0; letter-spacing:-1px\"><span>Terms</span></h3>" . str_replace("\n", "<br />", $r['terms']);
			}
			break;
		}
	}
}
?>
