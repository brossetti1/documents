<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
    <form name="showForm"  id="showForm" method="POST" action="show_list_of_villas.php?limit_from=0&limit_amount=10">
    Country&nbsp;<input type="text" name='country' id='country' value="2" /><br />
    Region&nbsp;<input type="text" name='region' id='region' value="1" /><br />
    Area&nbsp;<input type="text" name='area' id='area' value="" /><br />
    Date&nbsp;<input type="text" name="fdate" id="fdate" value="01/06/2012" /> <br /> 
    Nights&nbsp;<input type="text" name="nights" id="tnights" value="7" /><br />
    Persons&nbsp;<input type="text" name="persons" id="persons" value="2" /><br />
    Price&nbsp;<input type="text" name="price" id="price" value="70" /><br />
    Price diversion&nbsp;<input type="text" name="price_diversion" id="price_diversion" value="0.3" /><br />
	Has pool = 
    <input type="checkbox" name="pool" value="pool" checked="checked" /><br />
	Hash internet
    <input type="checkbox" name="internet" value="internet" checked="checked" /><br />
	Sort by distance from beach 
    <input type="checkbox" name="beach_distance" value="beach_distance" /><br />
    <input type="submit" value="show villas" />
    </form>
<?php

?>
</body>
</html>
