<?php
require_once("info.php");

$param = array('id'=>$TO_id);
$reply = $client->call('getAreaStructure',array('parameters' => $param));
if ($client->fault){
	print_r($reply);
} else {
	$err=$client->getError();
	if ($err!="")
		echo $err;
	else {
		$countryList = $reply['countryList'];
		$regionList = $reply['regionList'];
		$areaList = $reply['areaList'];
		
		$countries = array();
		foreach( $countryList as $c ) {
			$countries[$c['id']] = $c['name'];
		}
		
		$region2country = array();
		$regions = array();
		foreach( $regionList as $c ) {
			$region2country[$c['id']] = $c['country_id'];
			$regions[$c['id']] = $c['name'];
		}
		
		$area2country = array();
		$area2region = array();
		$areas = array();
		foreach( $areaList as $c ) {
			$area2country[$c['id']] = $region2country[$c['region_id']];
			$area2region[$c['id']] = $c['region_id'];
			$areas[$c['id']] = $c['name'];
		}
		
		echo "<b>Areas</b><br />"
			. "<table><tr><th>id</th><th>area</th><th>region</th><th>country</th></tr>";
		foreach( $areas as $key => $value ) {
			echo "<tr><td>".$key."</td><td>".$value."</td><td>".$regions[$area2region[$key]]."</td><td>".$countries[$area2country[$key]]."</td></tr>";
		}
		echo "</table><br /><b>Regions</b><br />"
			. "<table><tr><th>id</th><th>region</th><th>country</th></tr>";
		foreach( $regions as $key => $value ) {
			echo "<tr><td>".$key."</td><td>".$value."</td><td>".$countries[$region2country[$key]]."</td></tr>";
		}
		echo "</table><br /><b>Countries</b><br />"
			. "<table><tr><th>id</th><th>country</th></tr>";
		foreach( $countries as $key => $value ) {
			echo "<tr><td>".$key."</td><td>".$value."</td></tr>";
		}
		echo "</table>";
	}
}
?>