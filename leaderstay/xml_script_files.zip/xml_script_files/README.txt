- info.php: Necessary file. Choose the corresponding lines, depending on whether you want to use the test or the original system (If you use the original system, then the TO_id should change to your own id
- area_structure.php: Prints all the ids and names of the areas
- price_catalogue.php: Prints the price catalogue (it needs the id of the villa as input on the url, p.ex. price_catalogue.php?villaid=113)
- reserve.php: Sends a reservation
- search_villas.php: Search for properties and returns a list (uses the file show_list_of_villas.php)
- villa_availability.php: Prints the availability of a property, either by starting from tomorrow, or for a specified year (look at the comments inthe file) (needs the id of the villa as input "villaid")
- villa_details.php: Prints all the details for a specified property. (needs the id of the villa as input "villaid")
- villa_hash.php: Prints the hash keys that correspond to each property (usefull if you want to store locally the property details, and you want to periodically check if there are any chagnes)
- nusoap.php: Necessary file for the calls and the systems communication. 

