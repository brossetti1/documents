<?php
require_once('nusoap.php');

/* The two following lines are for the test system 
	Comment them if you want to make calls in the original system*/
$client = new nusoap_client('http://leaderstay.com/testing/leaderstay.php');
$imagepath = "http://www.leaderstay.com/testing/images/villas/";

/* The two following lines are for the original system 
	Comment them if you want to make calls in the test system*/
//$client = new nusoap_client('http://leaderstay.com/leaderstay.php');
//$imagepath = "http://www.leaderstay.com/images/villas/";

$TO_id = 1; // TODO: Write your id here
?>