<?php
require_once("info.php");

$param = array(	'id'=>$TO_id, 
		'code' => "3o4rthrskj", 
		'firstname'  => "myname" , 
		'lastname' => "kp" ,
		'email'  => "i.koutaki@leaderstay.com", 
		'telnumber'=> "6987543210" ,
		'countryofresidence'=> "gr", 
		'propertycode'=> "3",  
		'checkindate'=> "14/11/2012",
		'numberofnights'=>"2",
		'persons'=>"3",
		'asksuitability'=> "pets|elderly or infirm",
		'flightno'=>"A123",
		'airport'=>"HER",
		'notes'=>"Notes of the reservation");
$reply = $client->call('reserve',array('parameters' => $param));

if ($client->fault){
	print_r($reply);
} else {
	$err=$client->getError();
	if ($err!="")
		echo $err;
	else {
		echo "The Response is: <br/>";
		echo "<BR>";
			echo "result=".$reply['result'] . " <br/>";
			echo "confirmationnumber=".$reply['confirmationnumber'] . " <br/>";
	}
}
