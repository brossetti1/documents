<?php 
require_once("info.php");
?>

    <form name="showForm"  id="showForm" method="POST" action="show_list_of_villas.php?limit_from=0&limit_amount=10">
<?php

$param = array(	'id'=>$TO_id);
if( isset( $_POST['fdate'] ) && $_POST['fdate'] !== "" ) {
	$param['checkindate'] = $_POST['fdate'];
}

if( isset( $_POST['nights'] ) && $_POST['nights'] !== "" ) {
	$param['nightsno'] = $_POST['nights'];
}

if( isset( $_POST['persons'] ) && $_POST['persons'] !== "" ) {
	$param['personsno'] = $_POST['persons'];
}

if( isset( $_POST['area'] ) && $_POST['area'] !== "" && $_POST['area'] !== "0" ) {
	$param['area'] = $_POST['area'];
} elseif( isset( $_POST['region'] ) && $_POST['region'] !== "" && $_POST['region'] !== "0" ) {
	$param['region'] = $_POST['region'];
} elseif( isset( $_POST['country'] ) && $_POST['country'] !== "" && $_POST['country'] !== "0" ) {
	$param['country'] = $_POST['country'];
}

$spool1 = $_POST["pool"];
if( $spool1 === 'pool' ) {
	$param['pool'] = "1";
}

if( isset($_POST['internet']) ){
	$param['internet'] = "1";
}
if( isset($_POST['beach_distance']) ){
	$param['sortby'] = "beach";
}


if( isset($_POST['price']) ){
	$param['price_per_day'] = $_POST['price'];
	$param['price_diversion'] = $_POST['price_diversion'];
}

$param['limit_from'] = $_GET['limit_from'];
$param['limit_amount'] = $_GET['limit_amount'];
//$param['offer_only'] = 1; Use this line in order to see only properties with offers
$reply = $client->call('getInfoAvailabilityList',array('parameters' => $param));

if ($client->fault){
	print_r($reply);
} else {
	$err=$client->getError();
	if ($err!="")
		echo $err;
	else {
	if( count($reply) == 0 ) {
		echo "<br/><br/><br/>No results found...<br/>";
	} else {
		echo "<b style=\"font-size:larger; color:#333399\">Results ".($_GET['limit_from']+1)." to ".($_GET['limit_from']+count($reply))
			. "</b>";
	}
		foreach ($reply as $key=>$value ) {
			?>
<table>
	<tr>
		<td valign="top" style="width:90px"> 
			<table>
				<tr>
					<td style="height:16px;text-align:left;z-index:1;">
						<div style="text-decoration:none; color:#505050; font-weight:bold;" ><?php echo $value['vname'];?></div>
					</td>
				</tr>
				<tr>
					<td style="text-align:left;z-index:0;"> 
                        <img src="<?php echo $imagepath.$value['image'];?>"  id="Image1" alt="" align="top" border="0" style="width:90px; height:68px">
					</td>
				</tr>
			</table>
		</td>
		<td valign="top" style="width:320px;height:117px;text-align:left;z-index:2;"> 
			<font style="font-size:13px" color="#000000" face="Arial"><?php echo $value['region'];?> &gt;&gt; <?php echo $value['area'];?>&nbsp;&nbsp; 
			<?php
			if( $value['is_on_request'] == 1 ) { ?>
			(on request)
			<?php }
			?>
			<br>
			<?php
			$smalldescr = substr(((string)$value['description']), 0, 200);
			echo $smalldescr;
			?>
			 ... </font>
		</td>
		<td valign="top" style="width:150px;height:117px;text-align:left; z-index:3; background-color:#d1dcfc">
			<font style="font-size:13px" color="#000000" face="Arial">
				<br>
				Max Persons: <?php echo $value['persons'];?><br>
				Bedrooms: <?php echo $value['bedroom_no'];?><br>
				Bathrooms: <?php echo $value['bathroom_no'];?><br />
                <?php if( isset($param['sortby']) && $value['distancename'] != NULL ) {
					echo "beach: ".$value['distancename']." ".$value['distancekm']."km<br />";
				}?>
				<b>Total price: <?php echo $value['price']." ".$value['currency'];
				if( $value['offer'] !== "" ) echo " (Offer: ".$value['offer'].")";?></b>
			</font>
		</td>
	</tr>
</table>
<?php
		}
	}
	if( isset($_POST['fdate']) ) {?>
		<input type="hidden" name="fdate" value="<?php echo $_POST["fdate"];?>" />
		<?php 
	}  
	if( isset($_POST['nights']) ) {?>
		<input type="hidden" name="nights" value="<?php echo $_POST["nights"];?>" />
		<?php 
	}  
	if( isset($_POST['persons']) ) {?>
		<input type="hidden" name="persons" value="<?php echo $_POST["persons"];?>" />
		<?php 
	}  
	if( isset($_POST['area']) ) {?>
		<input type="hidden" name="area" value="<?php echo $_POST["area"];?>" />
		<?php 
	}  
	if( isset($_POST['region']) ) {?>
		<input type="hidden" name="region" value="<?php echo $_POST["region"];?>" />
		<?php 
	}  
	if( isset($_POST['country']) ) {?>
		<input type="hidden" name="country" value="<?php echo $_POST["country"];?>" />
		<?php 
	}  
	if( isset($_POST['pool']) ) {?>
		<input type="hidden" name="pool" value="<?php echo $_POST["pool"];?>" />
		<?php 
	}  
	if( isset($_POST['internet']) ) {?>
		<input type="hidden" name="internet" value="<?php echo $_POST["internet"];?>" />
		<?php 
	}  
	if( isset($_POST['beach_distance']) ) {?>
		<input type="hidden" name="beach_distance" value="<?php echo $_POST["beach_distance"];?>" />
		<?php 
	}  
	if( isset($_POST['price']) ) {?>
		<input type="hidden" name="price" value="<?php echo $_POST["price"];?>" />
		<?php 
	}  
	if( isset($_POST['price_diversion']) ) {?>
		<input type="hidden" name="price_diversion" value="<?php echo $_POST["price_diversion"];?>" />
		<?php 
	}  
	if($_GET['limit_from'] > 0) {?>
		<input type="submit" value="Previous" style="cursor:pointer" onClick="document.getElementById('showForm').action='show_list_of_villas.php?limit_from=<?php echo ($_GET['limit_from']-$_GET['limit_amount']);?>&limit_amount=<?php echo $_GET['limit_amount'];?>';document.getElementById('showForm').submit()" title="Prev"/>
	<?php 
	}
	if( count($reply) >= $_GET['limit_amount'] ) { ?>
		<input type="submit" value="Next" style="cursor:pointer" onClick="document.getElementById('showForm').action='show_list_of_villas.php?limit_from=<?php echo ($_GET['limit_from']+$_GET['limit_amount']);?>&limit_amount=<?php echo $_GET['limit_amount'];?>';document.getElementById('showForm').submit()" title="Next"/>
	<?php 
	}
}
?>
