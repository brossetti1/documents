<?php
function create_catalogue( $villaid ) {
	require_once("info.php");

	$param = array(	'id'=>$TO_id, 'propertycode'=>$villaid);
	
	$reply = $client->call('getPriceCatalogue',array('parameters' => $param));
	
	if ($client->fault){
		print_r($reply);
	} else {
		$err=$client->getError();
		if ($err!="")
			echo $err;
		else {
			$catalogue = array();
			$min_stay = array();
			$unsetlist = array();
			foreach ($reply as $r ) {
				$dateparts = explode("-", $r['sfrom']);
				$sfrom = $dateparts[2]."/".$dateparts[1]."/".$dateparts[0];
				$dateparts = explode("-", $r['sto']);
				$sto = $dateparts[2]."/".$dateparts[1]."/".$dateparts[0];
				$min_stay[$sfrom." - ".$sto] = $r['min_stay'];
				if( $r['pax'] == NULL ) {
					$catalogue[$sfrom." - ".$sto] = $r['price'];
				} else {
					$pax = $r['pax'];
					if( $pax > 1 ) {
						$prevpax = $pax;
						do {
							$prevpax = $prevpax - 1;
							$prevpaxprice = $catalogue[$sfrom." - ".$sto][$prevpax];
						} while( $prevpaxprice == NULL && $prevpax > 1 ) ;
						if( $prevpaxprice != NULL ) {
							if( $prevpaxprice != $r['price'] ) {
								//if( $prevpax == 1 ) {
									$catalogue[$sfrom." - ".$sto][$prevpax."-".($pax-1)] = $prevpaxprice;
									$unsetlist[$sfrom." - ".$sto.$prevpax] = 1; 
								//}
								$catalogue[$sfrom." - ".$sto][$pax] = $r['price'];
							}
						} else {
							$catalogue[$sfrom." - ".$sto] = array($pax=>$r['price']);
						}
					} else {
						$catalogue[$sfrom." - ".$sto] = array($pax=>$r['price']);
					}
				}
			}
			
			$minprice = 9999999999;
			$maxprice = 0;
			$string_output = "";
			$datefrom = "";
			$dateto = "";
			$counter = 1;
			foreach ( $catalogue as $key => $value) {
				$string_output .= $key.": ";
				$dates = explode(" - ", $key);
				$datefrom = $dates[0];
				$dateto = $dates[1];
				if( is_array($value) ) {
					foreach( $value as $k2 => $v2 ) {
						if( NULL == $unsetlist[$key.$k2] ) {
							$personsparts = explode("-", $k2);
							$minpersons = $k2;
							$maxpersons = $k2;
							if( count($personsparts) > 1 ) {
								$minpersons = $personsparts[0];
								$maxpersons = $personsparts[1];
							}
							$counter++;
							if( $v2 < $minprice ) $minprice = $v2;
							if( $v2 > $maxprice ) $maxprice = $v2;
							if( $minpersons == $maxpersons ) $string_output .= $v2." (".$minpersons." persons)&nbsp;";
							else $string_output .= $v2." (".$k2." persons)&nbsp;";
						}
					}
				} else {
					if( NULL == $unsetlist[$key.$k2] ) {
						$personsparts = explode("-", $k2);
						$counter++;
						if( $value < $minprice ) $minprice = $value;
						if( $value > $maxprice ) $maxprice = $value;
						$string_output .= $value;
					}
				}
				$string_output .= "&nbsp;minstay: ".$min_stay[$key]."<br>";
			}
		}
	}
	$output = array('minprice'=>$minprice, 'maxprice'=>$maxprice, 'string_output'=>$string_output);
	return $output;
}

$catalogue = create_catalogue( $_GET['villaid'] );
echo "minimum price: ".$catalogue['minprice']."&nbsp;-&nbsp;maximum price: ".$catalogue['maxprice']."<br />";
echo $catalogue['string_output']."<br>";
?>
