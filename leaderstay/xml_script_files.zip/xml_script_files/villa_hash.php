<?php
require_once("info.php");

$param = array(	'id'=>$TO_id);

$reply = $client->call('getGlobalHash',array('parameters' => $param));

if ($client->fault){
	print_r($reply);
} else {
	$err=$client->getError();
	if ($err!="")
		echo $err;
	else {
		echo "The global hash code that indicates if there has been any change in the details of any property is this: ";
		echo "&nbsp;".$reply['hash']."<br />";
	}
}

echo "<br>The following hash codes help someone to check which properties have changes in their details. <br>(Usefull only if you want to store the details in your server)<br><ul>";
$param = array(	'id'=>$TO_id, 'check'=>"1");

$reply = $client->call('getAvailableInfo',array('parameters' => $param));

if ($client->fault){
	print_r($reply);
} else {
	$err=$client->getError();
	if ($err!=""){
		echo $err;
	}else {
		foreach ($reply as $r ) {
			echo "<li>id: ".$r['villaid']." - hash_key: ".$r['hash_key']."</li>";
		}

	}
}
echo "</ul>";
?>