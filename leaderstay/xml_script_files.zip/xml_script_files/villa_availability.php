<?php
require_once("info.php");

$villaid = $_GET['villaid'];

// TODO: Choose one of the following lines. The first line refers to a year beginning from the 1st of January.
//		The second refers to a year beginning from tomorrow
//$param = array('id'=>$TO_id, 'propertycode'=> $villaid, 'year'=>'2012');
$param = array('id'=>$TO_id, 'propertycode'=> $villaid);

$reply = $client->call('getYearAvailability',array('parameters' => $param));

if ($client->fault){
	print_r($reply);
} else {
	$err=$client->getError();
	if ($err!="")
		echo $err;
	else {
		$availabilitystring= $reply['availabilitystring'];

		$reserved_days = array();
		$option_days = array();
		$format1 = 'Y-m-d'; 
// TODO: If your above choise was to begin from the 1st of January then choose this:
		//$firstdate = '2012-01-01';
//		otherwise choose the following line:
		$firstdate = date($format1);
		$usersTS = strtotime($firstdate); 
		$nextdate = date($format1, strtotime('+1 day', $usersTS));
		for($i=0;$i<strlen($availabilitystring); $i++){
			$rindex = count($reserved_days)-1;
			$reserved_days[$i] = substr($availabilitystring, $i, 1);
			$datereserved_piecesparts = explode("-", $nextdate);
			$reserved_dd = $datereserved_piecesparts[2];
			$reserved_mm = $datereserved_piecesparts[1];
			$reserved_Y = $datereserved_piecesparts[0];
			if( $reserved_days[$i] == 0 ) {
				echo $reserved_dd."/".$reserved_mm."/".$reserved_Y.": Available<br />";
			} elseif( $reserved_days[$i] == 1 ) {
				echo $reserved_dd."/".$reserved_mm."/".$reserved_Y.": Booked<br />";
			} elseif( $reserved_days[$i] == 2 ) {
				echo $reserved_dd."/".$reserved_mm."/".$reserved_Y.": Available on Request<br />";
			} elseif( $reserved_days[$i] == 3 ) {
				echo $reserved_dd."/".$reserved_mm."/".$reserved_Y.": Optioned Booked (expires soon)<br />";
			}
			$usersTS = strtotime($nextdate); 
			$nextdate = date($format1, strtotime('+1 day', $usersTS));
		} 
	}
}
?>