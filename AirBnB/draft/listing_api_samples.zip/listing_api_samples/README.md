Demonstration Code Samples for Airbnb Listing API

This code is confidential to early beta partners and under terms of partner NDA and API terms of service.

Last updated 2/17/2014

To use:

- Ensure you have valid OAuth code, token, API key, client secret, etc.
- In lib/utils.sh, replace placeholder values with a valid values
- Ensure scripts are executable ( chmod a+x FILENAME.sh )
- Run scripts from within directory. Example: ./get.sh
- You can pass optional parameters to scripts on a command level by specifying the value at the command line.
- Try modifying the example JSON put, post bodies, etc.
- Try using different images
- Questions or bugs? Ask ben.lowenstein@airbnb.com
