#!/bin/sh
# Usage:
#  ACCESS_TOKEN=abc LISTING_PHOTO_ID=xyz ./delete.sh

my_dir="$(dirname "$0")"
source "$my_dir/../lib/utils.sh"

OUTPUT_FILE="$my_dir/del_output.txt"
URL="$WEB_LINK/listing_photos/$LISTING_PHOTO_ID"
ACTION="DELETE"

CURL_CMD="curl -X $ACTION -H '$ACCESS_TOKEN_HEADER' $URL"
execute_curl_command "${CURL_CMD}" "${OUTPUT_FILE}"
