#!/bin/sh

# Usage:
#  ACCESS_TOKEN=abc LISTING_ID=123 IMAGE_URL=http://example.com/a.jpg ./post.sh

my_dir="$(dirname "$0")"
source "$my_dir/../lib/utils.sh"

: ${IMAGE_URL="http://interiordesigngiants.com/wp-content/uploads/2013/10/Casa-Big-Sur1.jpg"}
INPUT_FILE="$my_dir/post_body.json"
INPUT_FILE_REPLACED="$my_dir/post_body.json.tmp"
OUTPUT_FILE="$my_dir/post_output.txt"
IMAGE_FILE="$my_dir/image.tmp"

URL="$WEB_LINK/listing_photos"
ACTION="POST"

rm -f $INPUT_FILE_REPLACED $IMAGE_FILE

# Download the image
curl -o $IMAGE_FILE $IMAGE_URL
base64_stream=`openssl base64 < $IMAGE_FILE | tr -d '\n'`

# Construct the post body
sed -e "s/<listing_id>/$LISTING_ID/g" $INPUT_FILE > $INPUT_FILE_REPLACED
echo "  \"image\":\"$base64_stream\"\n}" >> $INPUT_FILE_REPLACED

CURL_CMD="curl -X $ACTION --data @$INPUT_FILE_REPLACED -H '$CONTENT_TYPE' -H '$ACCESS_TOKEN_HEADER' $URL"
execute_curl_command "${CURL_CMD}" "${OUTPUT_FILE}"
