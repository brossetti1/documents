#!/bin/sh

my_dir="$(dirname "$0")"
source "$my_dir/../lib/utils.sh"

OUTPUT_FILE="$my_dir/get_output.txt"

URL="$WEB_LINK/listing_photos/$LISTING_PHOTO_ID"

CURL_CMD="curl -H '$ACCESS_TOKEN_HEADER' $URL"
execute_curl_command "${CURL_CMD}" "${OUTPUT_FILE}"
