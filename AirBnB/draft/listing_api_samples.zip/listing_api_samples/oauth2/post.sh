#!/bin/sh

if [ $# -lt 1 ]; then
  echo "
  Usage: ./post.sh <type> <ID> <reset_flag>
  e.g. ./post.sh code <code>
  e.g. ./post.sh refresh_token <refresh_token> 1
  "
  exit 1
fi

my_dir="$(dirname "$0")"
source "$my_dir/../lib/utils.sh"

OUTPUT_FILE="$my_dir/post_output.txt"

URL="$WEB_LINK/oauth2/authorizations/"
ACTION="POST"

TYPE=$1
ID=$2

if [ -z "$ID" ]; then
  if [ "$TYPE" = "code" ]; then
    ID=$DEFAULT_CODE
  else
    ID=$REFRESH_TOKEN
  fi
fi


if [ ! -z "$3" ]; then
  RESET_OPTION=",\"reset_refresh_token\":$3"
fi

BODY="{\"${TYPE}\": \"${ID}\"${RESET_OPTION}}"

CURL_CMD="curl -X $ACTION --data '${BODY}' -H '$CONTENT_TYPE' -H '$CLIENT_ID_HEADER' -H '$CLIENT_SECRET_HEADER' $URL"
execute_curl_command "${CURL_CMD}" "${OUTPUT_FILE}"
