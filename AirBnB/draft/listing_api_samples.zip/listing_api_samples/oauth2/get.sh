#!/bin/sh

if [ $# -lt 2 ]; then
  echo "
  Usage: ./get.sh <resource> <ID>
  e.g. ./get.sh clients <client_id>
  e.g. ./get.sh authorizations <token>
  "
  exit 1
fi

my_dir="$(dirname "$0")"
source "$my_dir/../lib/utils.sh"

OUTPUT_FILE="$my_dir/get_output.txt"

RESOURCE=$1
ID=$2

URL="$WEB_LINK/oauth2/${RESOURCE}/${ID}"

CURL_CMD="curl -H '$CLIENT_ID_HEADER' -H '$CLIENT_SECRET_HEADER' $URL"
execute_curl_command "${CURL_CMD}" "${OUTPUT_FILE}"
