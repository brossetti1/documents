#!/bin/sh

my_dir="$(dirname "$0")"
source "$my_dir/../lib/utils.sh"

INPUT_FILE="$my_dir/put_body.json"
OUTPUT_FILE="$my_dir/put_output.txt"

URL="$WEB_LINK/listings/$LISTING_ID?_format=$FORMAT"
ACTION="PUT"

CURL_CMD="curl -X $ACTION --data @$INPUT_FILE -H '$CONTENT_TYPE' -H '$ACCESS_TOKEN_HEADER' $URL"
execute_curl_command "${CURL_CMD}" "${OUTPUT_FILE}"
