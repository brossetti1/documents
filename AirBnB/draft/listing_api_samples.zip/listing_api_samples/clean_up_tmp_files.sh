#!/bin/sh

# Clean up temp files
find ./ | grep -e ".*\.txt" -e ".*\.tmp" | xargs rm -f
