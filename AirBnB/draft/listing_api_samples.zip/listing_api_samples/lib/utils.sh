#!/bin/sh

#
# REPLACE THESE VARS WITH REAL VALUES!
#
#
: ${ACCESS_TOKEN="your_access_token"}
: ${REFRESH_TOKEN="your_refresh_token"}
: ${DEFAULT_CODE="your_code"}
: ${LOCALE="en"}
: ${LISTING_ID=123456}
: ${LISTING_PHOTO_ID=65489114}
: ${WEB_LINK="https://api.airbnb.com/v2"}
: ${FORMAT="platform_partner"}
: ${USER_ID=12345}
: ${CLIENT_ID="your_client_id"}
: ${CLIENT_SECRET="your_client_secret"}
#
# END REPLACE
#


CLIENT_ID_HEADER="X-Airbnb-API-Key: ${CLIENT_ID}"
CLIENT_SECRET_HEADER="X-Airbnb-API-Secret: ${CLIENT_SECRET}"
CONTENT_TYPE="Content-Type: application/json"
ACCESS_TOKEN_HEADER="X-Airbnb-OAuth-Token: $ACCESS_TOKEN"

print_response() {
  echo "Output:"
  cat $1 | python -m json.tool
  echo
}

# $1 : curl command to execute
# $2 : output file to save / display response
execute_curl_command() {
  echo $1
  if [ ! -z "$2" ]; then
    rm -f $2
    eval "$1 > $2"
    print_response $2
  else
    eval "$1"
  fi
}
